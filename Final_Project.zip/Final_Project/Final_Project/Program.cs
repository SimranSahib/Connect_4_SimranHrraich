﻿// Simranjit Singh
//BVC ID - 425011
// Final Project of Object Oriented Programming
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOB_project
{
    class Connect4
    {
        private const int numColsRows = 9;
        private static char[,] board = new char[numColsRows, numColsRows];
        private static bool[] columnFull = new bool[numColsRows];
        private static char currentPlayerSymbol;
        private static int chosenColumn = 0;
        private static bool done = false;
        private static bool simulation = false;

        static void Main(string[] args)
        {
            Console.WriteLine("Connect 4\n");
            Console.WriteLine("Both the players will select one column to put  their symbol at their turn.");
            Console.WriteLine("The player that will have 4 dices in a row first will win the game. It can be in any direction, upright, layed down or diaognally");
            Console.WriteLine("\nPLAYER 1 (S) and PLAYER 2 (M).");

            if (!simulation)
            {
                Console.WriteLine("Choose who will be the First and Second player respectively.");
                Console.WriteLine("Press enter once decided");
                Console.ReadLine();
            }
            else
            {
                Console.WriteLine("SIMRAN vs MANDY");
            }
            InitializeBoard();
            displayBoard();

            int determineFirstPLayer = new Random().Next() % 2;

            if (determineFirstPLayer == 0)
            {
                currentPlayerSymbol = 'X';
                Console.WriteLine("First Player's Turn.");
            }
            else
            {
                currentPlayerSymbol = 'O';
                Console.WriteLine("Second Player's Turn.");
            }

            do
            {
                if (currentPlayerSymbol == 'X')
                {
                    Console.WriteLine("PLAYER 1: ");
                }
                else
                {
                    Console.Write("PLAYER 2: \n");
                }

                try
                {
                    if (simulation)
                    {
                        chosenColumn = new Random().Next() % 9;
                        Console.WriteLine("User {0} chose column {1}", currentPlayerSymbol, chosenColumn);
                    }
                    else
                    {
                        double temp = Double.Parse(Console.ReadLine());
                        chosenColumn = (int)temp;
                    }

                    if (chosenColumn >= 0 && chosenColumn <= 8)
                    {
                        positionInColumn(chosenColumn, currentPlayerSymbol);
                        if (WinConditionMet(currentPlayerSymbol))
                        {
                            Console.WriteLine("Player {0} is the Winner !", currentPlayerSymbol);
                            PlayAgain();
                        }
                        else if (!columnFull[chosenColumn])
                        {
                            currentPlayerSymbol = (currentPlayerSymbol == 'O' ? 'X' : 'O');
                        }

                        if (NoMoreSpace())
                        {
                            Console.WriteLine("IT'S A TIE");
                            PlayAgain();
                        }
                    }
                    else
                    {
                        Console.WriteLine("Choose any number from 0 to 8.");
                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("Choose any number from 0 to 8.");
                }
            } while (!done);
        }

        private static void PlayAgain()
        {
            Console.WriteLine(" YES(1) for playing again and NO(0) to quit");
            if (Console.ReadLine().ToUpper().StartsWith("1"))
            {
                InitializeBoard();
                if (currentPlayerSymbol == 'O') currentPlayerSymbol = 'X';
                else currentPlayerSymbol = 'O';
                done = false;
            }
            else done = true;
        }

        private static void InitializeBoard()
        {
            for (int i = 0; i < numColsRows; i++)
            {
                columnFull[i] = false;
                for (int j = 0; j < numColsRows; j++)
                    board[i, j] = '*';
            }
        }

        private static bool WinConditionMet(char cps)
        {
            bool winOrNot = false;

            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 6; j++)
                {
                    if (board[i, j] == cps &&
                        board[i, j + 1] == cps &&
                        board[i, j + 2] == cps &&
                        board[i, j + 3] == cps)
                    {
                        Console.WriteLine("GAME OVER!4 Same symbols detected - Row {0}, Column {1}.", i, j);
                        winOrNot = true;
                    }
                }
            }

            for (int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    if (board[i, j] == cps &&
                        board[i + 1, j] == cps &&
                        board[i + 2, j] == cps &&
                        board[i + 3, j] == cps)
                    {
                        Console.WriteLine("GAME OVER!4 Same symbols detected - Row {0}, Column {1}", i, j);
                        winOrNot = true;
                    }
                }
            }

            for (int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 6; j++)
                {
                    if (board[i, j] == cps &&
                        board[i + 1, j + 1] == cps &&
                        board[i + 2, j + 2] == cps &&
                        board[i + 3, j + 3] == cps)
                    {
                        Console.WriteLine("GAME OVER!4 Same symbols detected - Row {0}, Column {1}", i, j);
                        winOrNot = true;
                    }
                }
            }

            for (int i = 0; i < 6; i++)
            {
                for (int j = 8; j < 3; j--)
                {
                    if (board[i, j] == cps &&
                        board[i + 1, j - 1] == cps &&
                        board[i + 2, j - 2] == cps &&
                        board[i + 3, j - 3] == cps)
                    {
                        Console.WriteLine("GAME OVER!4 Same symbols detected - Row {0}, Column {1}", i, j);
                        winOrNot |= true;
                    }
                }
            }
            return winOrNot;
        }

        private static bool NoMoreSpace()
        {
            bool boardIsFull = true;
            for (int i = 0; i < numColsRows; i++) if (!columnFull[i]) boardIsFull = false;
            return boardIsFull;
        }
        private static void displayBoard()
        {
            Console.WriteLine("\n\n 012345678");
            for (int i = 1; i < numColsRows; i++)
            {
                Console.Write("|");
                for (int j = 0; j < numColsRows; j++)
                {
                    Console.Write(Connect4.board[i, j]);
                }
                Console.WriteLine();
            }
        }
        private static void positionInColumn(int columnNumber, char symbol)
        {
            int index = numColsRows - 1;
            char cc = Connect4.board[index, columnNumber];
            while ((cc == 'X' || cc == 'O') && index >= 0)
            {
                index--;
                if (index >= 0) cc = Connect4.board[index, columnNumber];
            }
            if (index < 0) columnFull[columnNumber] = true;
            if (!columnFull[columnNumber])
            {
                Connect4.board[index, columnNumber] = symbol;
                displayBoard();
            }
            else
            {
                Console.WriteLine("COLUMN IS FULL!");
            }
        }
    }
}
